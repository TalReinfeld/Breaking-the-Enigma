package parts;

public interface Reflector {
    int indexToIndex(int index);
}
