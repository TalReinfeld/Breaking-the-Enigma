public interface MachineAbilities {
    String encrypt(String note);
}
